import React, { useState } from 'react';
import { Coffee, UtensilsCrossed, Clock, Star, MapPin, Sparkles, Crown, Heart, Award } from 'lucide-react';

function App() {
  const [activeCategory, setActiveCategory] = useState('breakfast');

  const categories = [
    { id: 'breakfast', name: 'Breakfast', icon: Coffee },
    { id: 'lunch', name: 'Lunch & Dinner', icon: UtensilsCrossed },
    { id: 'beverages', name: 'Beverages', icon: Coffee },
    { id: 'desserts', name: 'Desserts', icon: Star },
    { id: 'specials', name: 'Chef Specials', icon: Crown },
    { id: 'healthy', name: 'Healthy Options', icon: Heart },
  ];

  const menuItems = {
    breakfast: [
      {
        id: 1,
        name: 'Royal Eggs Benedict',
        description: 'Poached eggs on brioche with truffle hollandaise, smoked salmon, and microgreens',
        price: '₹1,410',
        originalPrice: '₹1,660',
        image: 'https://images.pexels.com/photos/101533/pexels-photo-101533.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true,
        chef: true
      },
      {
        id: 2,
        name: 'Avocado Toast Supreme',
        description: 'Smashed avocado on sourdough with burrata, cherry tomatoes, pomegranate, and balsamic pearls',
        price: '₹1,080',
        image: 'https://images.pexels.com/photos/1351238/pexels-photo-1351238.jpeg?auto=compress&cs=tinysrgb&w=600',
        new: true
      },
      {
        id: 3,
        name: 'Golden Pancakes Tower',
        description: 'Five fluffy pancakes with maple butter, fresh berries, candied pecans, and vanilla bean cream',
        price: '₹1,245',
        image: 'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true
      },
      {
        id: 4,
        name: 'Gourmet Breakfast Burrito',
        description: 'Scrambled eggs, chorizo, aged cheddar, roasted peppers, and chipotle aioli in a spinach tortilla',
        price: '₹995',
        image: 'https://images.pexels.com/photos/461198/pexels-photo-461198.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 5,
        name: 'Mediterranean Yogurt Bowl',
        description: 'Greek yogurt with honey, pistachios, figs, granola, and rose petals',
        price: '₹830',
        image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 6,
        name: 'Premium English Breakfast',
        description: 'Free-range eggs, artisan sausages, thick-cut bacon, grilled tomatoes, mushrooms, and sourdough',
        price: '₹1,575',
        image: 'https://images.pexels.com/photos/70497/pexels-photo-70497.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      },
      {
        id: 7,
        name: 'French Toast Royale',
        description: 'Brioche French toast with cinnamon butter, caramelized bananas, and bourbon maple syrup',
        price: '₹1,160',
        image: 'https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 8,
        name: 'Smoked Salmon Bagel',
        description: 'Everything bagel with cream cheese, smoked salmon, capers, red onion, and dill',
        price: '₹1,330',
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true
      }
    ],
    lunch: [
      {
        id: 9,
        name: 'Wagyu Beef Burger',
        description: 'Premium wagyu patty with truffle aioli, aged gruyere, arugula, and caramelized onions',
        price: '₹2,075',
        image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true,
        popular: true
      },
      {
        id: 10,
        name: 'Lobster Caesar Salad',
        description: 'Fresh lobster tail over crisp romaine with parmesan crisps and house Caesar dressing',
        price: '₹2,405',
        image: 'https://images.pexels.com/photos/2097090/pexels-photo-2097090.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      },
      {
        id: 11,
        name: 'Pan-Seared Salmon',
        description: 'Atlantic salmon with lemon herb crust, quinoa pilaf, and seasonal vegetables',
        price: '₹1,910',
        image: 'https://images.pexels.com/photos/3622479/pexels-photo-3622479.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 12,
        name: 'Truffle Chicken Parmesan',
        description: 'Herb-crusted chicken with truffle marinara, fresh mozzarella, and angel hair pasta',
        price: '₹1,825',
        image: 'https://images.pexels.com/photos/2233348/pexels-photo-2233348.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true
      },
      {
        id: 13,
        name: 'Wild Mushroom Risotto',
        description: 'Creamy arborio rice with porcini, shiitake, truffle oil, and aged parmesan',
        price: '₹1,660',
        image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 14,
        name: 'Bourbon BBQ Ribs',
        description: 'Slow-cooked pork ribs with bourbon glaze, coleslaw, and sweet potato fries',
        price: '₹2,240',
        image: 'https://images.pexels.com/photos/13163536/pexels-photo-13163536.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      },
      {
        id: 15,
        name: 'Duck Confit Salad',
        description: 'Crispy duck leg with mixed greens, candied walnuts, dried cranberries, and orange vinaigrette',
        price: '₹1,990',
        image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600',
        new: true
      },
      {
        id: 16,
        name: 'Seafood Paella',
        description: 'Traditional Spanish rice with shrimp, mussels, clams, and saffron',
        price: '₹2,490',
        image: 'https://images.pexels.com/photos/16743489/pexels-photo-16743489.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      }
    ],
    beverages: [
      {
        id: 17,
        name: 'Golden Latte',
        description: 'Espresso with steamed milk, turmeric, honey, and edible gold flakes',
        price: '₹580',
        image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true,
        new: true
      },
      {
        id: 18,
        name: 'Fresh Pressed Orange Juice',
        description: 'Daily squeezed Valencia oranges with a hint of mint',
        price: '₹495',
        image: 'https://images.pexels.com/photos/1233319/pexels-photo-1233319.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 19,
        name: 'Superfood Green Smoothie',
        description: 'Spinach, kale, mango, pineapple, chia seeds, and coconut water',
        price: '₹745',
        image: 'https://images.pexels.com/photos/775032/pexels-photo-775032.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 20,
        name: 'Craft Beer Selection',
        description: 'Rotating selection of local brewery favorites and seasonal specialties',
        price: '₹665',
        image: 'https://images.pexels.com/photos/1552630/pexels-photo-1552630.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 21,
        name: 'Signature Cocktails',
        description: 'House-crafted cocktails with premium spirits and fresh ingredients',
        price: '₹1,080',
        image: 'https://images.pexels.com/photos/1304540/pexels-photo-1304540.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true
      },
      {
        id: 22,
        name: 'Matcha Ceremonial Latte',
        description: 'Premium ceremonial grade matcha with oat milk and vanilla',
        price: '₹665',
        image: 'https://images.pexels.com/photos/4226894/pexels-photo-4226894.jpeg?auto=compress&cs=tinysrgb&w=600',
        new: true
      }
    ],
    desserts: [
      {
        id: 23,
        name: 'Molten Chocolate Volcano',
        description: 'Warm chocolate cake with liquid center, vanilla bean ice cream, and gold leaf',
        price: '₹1,080',
        image: 'https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true,
        chef: true
      },
      {
        id: 24,
        name: 'Classic Tiramisu',
        description: 'Traditional Italian dessert with espresso-soaked ladyfingers and mascarpone',
        price: '₹830',
        image: 'https://images.pexels.com/photos/4913399/pexels-photo-4913399.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 25,
        name: 'Berry Parfait Tower',
        description: 'Layers of vanilla custard, fresh berries, and almond crumble in a glass',
        price: '₹745',
        image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 26,
        name: 'New York Cheesecake',
        description: 'Rich and creamy cheesecake with graham crust and berry compote',
        price: '₹790',
        image: 'https://images.pexels.com/photos/955137/pexels-photo-955137.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 27,
        name: 'Crème Brûlée Trio',
        description: 'Vanilla, lavender, and chocolate crème brûlée with caramelized sugar',
        price: '₹995',
        image: 'https://images.pexels.com/photos/3026804/pexels-photo-3026804.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      },
      {
        id: 28,
        name: 'Macaroon Tower',
        description: 'Assorted French macaroons with seasonal flavors and edible flowers',
        price: '₹1,245',
        image: 'https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true
      }
    ],
    specials: [
      {
        id: 29,
        name: 'Chef\'s Tasting Menu',
        description: '7-course culinary journey featuring seasonal ingredients and innovative techniques',
        price: '₹7,470',
        image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true,
        popular: true
      },
      {
        id: 30,
        name: 'Lobster Thermidor',
        description: 'Whole lobster with cognac cream sauce, gruyere, and herb crust',
        price: '₹3,815',
        image: 'https://images.pexels.com/photos/725991/pexels-photo-725991.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      },
      {
        id: 31,
        name: 'Dry-Aged Ribeye',
        description: '28-day aged ribeye with truffle butter, roasted vegetables, and red wine jus',
        price: '₹4,400',
        image: 'https://images.pexels.com/photos/361184/asparagus-steak-veal-steak-veal-361184.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      },
      {
        id: 32,
        name: 'Caviar Service',
        description: 'Premium Ossetra caviar with traditional accompaniments and champagne',
        price: '₹10,455',
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg?auto=compress&cs=tinysrgb&w=600',
        chef: true
      }
    ],
    healthy: [
      {
        id: 33,
        name: 'Buddha Bowl Supreme',
        description: 'Quinoa, roasted vegetables, avocado, chickpeas, and tahini dressing',
        price: '₹1,245',
        image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=600',
        popular: true
      },
      {
        id: 34,
        name: 'Acai Power Bowl',
        description: 'Acai puree with granola, fresh fruits, coconut flakes, and chia seeds',
        price: '₹995',
        image: 'https://images.pexels.com/photos/775032/pexels-photo-775032.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 35,
        name: 'Grilled Chicken Salad',
        description: 'Free-range chicken with mixed greens, quinoa, and lemon vinaigrette',
        price: '₹1,410',
        image: 'https://images.pexels.com/photos/2097090/pexels-photo-2097090.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        id: 36,
        name: 'Vegan Protein Bowl',
        description: 'Plant-based protein with brown rice, steamed vegetables, and miso dressing',
        price: '₹1,160',
        image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600',
        new: true
      }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-amber-50 to-orange-100">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-yellow-200 to-amber-200 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-gradient-to-r from-orange-200 to-red-200 rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute bottom-40 left-1/4 w-40 h-40 bg-gradient-to-r from-amber-200 to-yellow-200 rounded-full opacity-15 animate-pulse"></div>
      </div>

      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md shadow-2xl sticky top-0 z-50 border-b border-amber-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Coffee className="h-10 w-10 text-amber-600 animate-pulse" />
                <Sparkles className="h-4 w-4 text-yellow-400 absolute -top-1 -right-1 animate-spin" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 bg-clip-text text-transparent">
                  The Golden Spoon
                </h1>
                <p className="text-sm text-gray-600 font-medium">✨ Premium Culinary Experience ✨</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-8 text-sm text-gray-600">
              <div className="flex items-center space-x-2 bg-amber-50 px-4 py-2 rounded-full">
                <Clock className="h-4 w-4 text-amber-600" />
                <span className="font-medium">7:00 AM - 11:00 PM</span>
              </div>
              <div className="flex items-center space-x-2 bg-orange-50 px-4 py-2 rounded-full">
                <MapPin className="h-4 w-4 text-orange-600" />
                <span className="font-medium">Downtown Premium</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full animate-float"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-white/10 rounded-full animate-float-delayed"></div>
          <div className="absolute bottom-20 left-1/3 w-24 h-24 bg-white/10 rounded-full animate-float"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full">
              <Award className="h-5 w-5 text-yellow-300" />
              <span className="text-sm font-semibold">Award Winning Cuisine</span>
              <Award className="h-5 w-5 text-yellow-300" />
            </div>
          </div>
          <h2 className="text-6xl font-bold mb-6 animate-fade-in">
            Exquisite <span className="text-yellow-300">Flavors</span>
          </h2>
          <p className="text-xl text-amber-100 max-w-3xl mx-auto leading-relaxed">
            Experience culinary excellence with our carefully crafted menu featuring premium ingredients, 
            innovative techniques, and unforgettable flavors that will transport your taste buds
          </p>
          <div className="mt-8 flex justify-center space-x-4">
            <div className="flex items-center space-x-2 text-yellow-300">
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <span className="ml-2 font-semibold">5.0 Rating</span>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Navigation */}
      <nav className="bg-white/95 backdrop-blur-md shadow-lg border-b sticky top-24 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-2 overflow-x-auto py-6 scrollbar-hide">
            {categories.map((category) => {
              const IconComponent = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={`flex items-center space-x-3 px-6 py-3 rounded-2xl whitespace-nowrap transition-all duration-300 transform hover:scale-105 ${
                    activeCategory === category.id
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xl shadow-amber-500/25 scale-105'
                      : 'text-gray-600 hover:text-amber-600 hover:bg-gradient-to-r hover:from-amber-50 hover:to-orange-50 bg-white shadow-md'
                  }`}
                >
                  <IconComponent className="h-5 w-5" />
                  <span className="font-semibold">{category.name}</span>
                  {activeCategory === category.id && (
                    <Sparkles className="h-4 w-4 animate-spin" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Menu Items */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h3 className="text-4xl font-bold text-gray-900 mb-4">
            {categories.find(cat => cat.id === activeCategory)?.name}
          </h3>
          <div className="w-24 h-1 bg-gradient-to-r from-amber-500 to-orange-500 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {menuItems[activeCategory as keyof typeof menuItems].map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 group relative"
            >
              {/* Shine Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
              
              <div className="relative overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-52 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col space-y-2">
                  {item.popular && (
                    <div className="bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center space-x-1 shadow-lg animate-pulse">
                      <Star className="h-3 w-3 fill-current" />
                      <span>Popular</span>
                    </div>
                  )}
                  {item.chef && (
                    <div className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center space-x-1 shadow-lg">
                      <Crown className="h-3 w-3 fill-current" />
                      <span>Chef's Choice</span>
                    </div>
                  )}
                  {item.new && (
                    <div className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center space-x-1 shadow-lg animate-bounce">
                      <Sparkles className="h-3 w-3 fill-current" />
                      <span>New</span>
                    </div>
                  )}
                </div>
                
                {/* Price Badge */}
                <div className="absolute top-3 right-3">
                  <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-2xl text-sm font-bold shadow-xl">
                    {item.price}
                    {item.originalPrice && (
                      <span className="line-through text-xs ml-2 opacity-75">{item.originalPrice}</span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-amber-600 transition-colors">
                  {item.name}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-6 line-clamp-3">
                  {item.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-2xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                      {item.price}
                    </span>
                    {item.originalPrice && (
                      <span className="text-sm text-gray-400 line-through">{item.originalPrice}</span>
                    )}
                  </div>
                  <button className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-6 py-3 rounded-2xl text-sm font-bold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center space-x-2">
                    <span>Order Now</span>
                    <Sparkles className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-amber-500/10 to-orange-500/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-4 mb-6">
                <div className="relative">
                  <Coffee className="h-10 w-10 text-amber-500" />
                  <Sparkles className="h-4 w-4 text-yellow-400 absolute -top-1 -right-1 animate-spin" />
                </div>
                <div>
                  <span className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">
                    The Golden Spoon
                  </span>
                  <p className="text-gray-400 text-sm">Premium Culinary Experience</p>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed mb-6">
                Serving exceptional food and creating memorable dining experiences since 2010. 
                Our commitment to quality ingredients and innovative cuisine has made us a destination 
                for food lovers seeking extraordinary flavors.
              </p>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1 text-yellow-400">
                  <Star className="h-4 w-4 fill-current" />
                  <Star className="h-4 w-4 fill-current" />
                  <Star className="h-4 w-4 fill-current" />
                  <Star className="h-4 w-4 fill-current" />
                  <Star className="h-4 w-4 fill-current" />
                </div>
                <span className="text-gray-300 text-sm">5.0 • 2,847 Reviews</span>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-bold mb-6 text-amber-400">Hours & Location</h3>
              <div className="space-y-3 text-gray-300">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-amber-500" />
                  <div>
                    <p className="font-medium">Mon - Fri: 7:00 AM - 11:00 PM</p>
                    <p>Sat - Sun: 8:00 AM - 12:00 AM</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-amber-500" />
                  <div>
                    <p>123 Premium Boulevard</p>
                    <p>Downtown District, City 12345</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-bold mb-6 text-amber-400">Contact & Reservations</h3>
              <div className="space-y-3 text-gray-300">
                <p className="flex items-center space-x-2">
                  <span className="font-medium">Phone:</span>
                  <span>(555) 123-4567</span>
                </p>
                <p className="flex items-center space-x-2">
                  <span className="font-medium">Email:</span>
                  <span>hello@goldenspoon.com</span>
                </p>
                <button className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-6 py-2 rounded-full text-sm font-bold transition-all duration-300 transform hover:scale-105 mt-4">
                  Make Reservation
                </button>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8 mt-12 text-center">
            <p className="text-gray-400 flex items-center justify-center space-x-2">
              <span>&copy; 2025 The Golden Spoon. All rights reserved.</span>
              <Heart className="h-4 w-4 text-red-500 animate-pulse" />
              <span>Made with love for food enthusiasts</span>
            </p>
          </div>
        </div>
      </footer>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        @keyframes float-delayed {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-15px); }
        }
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        .animate-float-delayed {
          animation: float-delayed 8s ease-in-out infinite;
        }
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
}

export default App;